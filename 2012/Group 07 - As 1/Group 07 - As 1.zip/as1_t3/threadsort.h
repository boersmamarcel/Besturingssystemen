void *merge_thread_sort(void* params);
void merge_sort(task_t **tasks, int left, int right);